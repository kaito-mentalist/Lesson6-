# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '80f1c52a2532c5cf3bd042ef3bf192788982e9dd7e25e1821951bc0f38db98b6f35ab23f474433f8d91e8f3b2b58b8d9f30dd7b785cdd088e3079622dc2f3999'